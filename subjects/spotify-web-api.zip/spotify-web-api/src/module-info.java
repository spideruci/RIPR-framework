module se.michaelthelin.spotify {
  requires com.fasterxml.jackson.databind;
  requires com.google.gson;
  requires nv.i18n;
  requires org.apache.httpcomponents.client5.httpclient5.cache;
  requires org.apache.httpcomponents.client5.httpclient5;
  requires org.apache.httpcomponents.core5.httpcore5;
}
