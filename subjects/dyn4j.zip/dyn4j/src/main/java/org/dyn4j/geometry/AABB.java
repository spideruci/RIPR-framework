/*
 * Copyright (c) 2010-2022 William Bittle  http://www.dyn4j.org/
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification, are permitted 
 * provided that the following conditions are met:
 * 
 *   * Redistributions of source code must retain the above copyright notice, this list of conditions 
 *     and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright notice, this list of conditions 
 *     and the following disclaimer in the documentation and/or other materials provided with the 
 *     distribution.
 *   * Neither the name of the copyright holder nor the names of its contributors may be used to endorse or 
 *     promote products derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR 
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND 
 * FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
 * IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package org.dyn4j.geometry;

import org.dyn4j.Copyable;
import org.dyn4j.exception.ValueOutOfRangeException;

/**
 * Implementation of an Axis-Align Bounding Box.
 * <p>
 * An {@link AABB} has minimum and maximum coordinates that define the box.
 * <p>
 * An {@link AABB} can be unioned or intersected with other {@link AABB}s to combine
 * them into another {@link AABB}.  If an intersection produces no result, a degenerate {@link AABB}
 * is returned.  A degenerate {@link AABB} can be tested by the {@link #isDegenerate()} methods and 
 * is defined as an {@link AABB} who's maximum and minimum are equal.
 * <p>
 * {@link AABB}s can also be tested for overlap and (full) containment using the {@link #overlaps(AABB)} 
 * and {@link #contains(AABB)} method.
 * <p>
 * The {@link #expand(double)} method can be used to expand the bounds of the {@link AABB} by some amount.
 * @author William Bittle
 * @version 5.0.0
 * @since 3.0.0
 */
public class AABB implements Translatable, Copyable<AABB> {
	/** The minimum extent along the x-axis */
	protected double minX;
	
	/** The minimum extent along the y-axis */
	protected double minY;
	
	/** The maximum extent along the x-axis */
	protected double maxX;
	
	/** The maximum extent along the y-axis */
	protected double maxY;
	
	/**
	 * Method to create the valid AABB defined by the two points point1 and point2.
	 * @param point1 the first point
	 * @param point2 the second point
	 * @return The one and only one valid AABB formed by point1 and point2
	 */
	public static AABB createFromPoints(Vector2 point1, Vector2 point2) {
		return createFromPoints(point1.x, point1.y, point2.x, point2.y);
	}
	
	/**
	 * Method to create the valid AABB defined by the two points A(point1x, point1y) and B(point2x, point2y).
	 * @param point1x The x coordinate of point A
	 * @param point1y The y coordinate of point A
	 * @param point2x The x coordinate of point B
	 * @param point2y The y coordinate of point B
	 * @return The one and only one valid AABB formed by A and B
	 */
	public static AABB createFromPoints(double point1x, double point1y, double point2x, double point2y) {
		AABB aabb = new AABB(0,0,0,0);
		setFromPoints(point1x, point1y, point2x, point2y, aabb);
		return aabb;
	}
	
	/**
	 * Method to create the valid AABB defined by the two points point1 and point2 and places the result
	 * in the given AABB.
	 * @param point1 the first point
	 * @param point2 the second point
	 * @param result the AABB to set
	 * @since 4.1.0
	 */
	public static void setFromPoints(Vector2 point1, Vector2 point2, AABB result) {
		setFromPoints(point1.x, point1.y, point2.x, point2.y, result);
	}
	
	/**
	 * Method to create the valid AABB defined by the two points A(point1x, point1y) and B(point2x, point2y) and places
	 * the result in the given AABB.
	 * @param point1x The x coordinate of point A
	 * @param point1y The y coordinate of point A
	 * @param point2x The x coordinate of point B
	 * @param point2y The y coordinate of point B
	 * @param result the AABB to set
	 * @since 4.1.0
	 */
	public static void setFromPoints(double point1x, double point1y, double point2x, double point2y, AABB result) {
		if (point2x < point1x) {
			double temp = point1x;
			point1x = point2x;
			point2x = temp;
		}
		
		if (point2y < point1y) {
			double temp = point1y;
			point1y = point2y;
			point2y = temp;
		}
		
		result.minX = point1x;
		result.minY = point1y;
		result.maxX = point2x;
		result.maxY = point2y;
	}
	
	/**
	 * Full constructor.
	 * @param minX the minimum x extent
	 * @param minY the minimum y extent
	 * @param maxX the maximum x extent
	 * @param maxY the maximum y extent
	 * @throws IllegalArgumentException if minX is greater than maxX or if minY is greater than maxY
	 */
	public AABB(double minX, double minY, double maxX, double maxY) {
		// check the min and max
		if (minX > maxX) 
			throw new ValueOutOfRangeException("minX", minX, ValueOutOfRangeException.MUST_BE_LESS_THAN_OR_EQUAL_TO, "maxX", maxX);
		
		if (minY > maxY) 
			throw new ValueOutOfRangeException("minY", minY, ValueOutOfRangeException.MUST_BE_LESS_THAN_OR_EQUAL_TO, "maxY", maxY);
		
		this.minX = minX;
		this.minY = minY;
		this.maxX = maxX;
		this.maxY = maxY;
	}
	
	/**
	 * Full constructor.
	 * @param min the minimum extent
	 * @param max the maximum extent
	 * @throws IllegalArgumentException if either coordinate of the given min is greater than the given max
	 */
	public AABB(Vector2 min, Vector2 max) {
		this(min.x, min.y, max.x, max.y);
	}
	
	/**
	 * Full constructor.
	 * @param radius the radius of a circle fitting inside an AABB
	 * @since 3.1.5
	 */
	public AABB(double radius) {
		this(null, radius);
	}
	
	/**
	 * Full constructor.
	 * <p>
	 * Creates an AABB for a circle with the given center and radius.
	 * @param center the center of the circle
	 * @param radius the radius of the circle
	 * @since 3.1.5
	 * @throws IllegalArgumentException if the given radius is less than zero
	 */
	public AABB(Vector2 center, double radius) {
		if (radius < 0) 
			throw new ValueOutOfRangeException("radius", radius, ValueOutOfRangeException.MUST_BE_GREATER_THAN_OR_EQUAL_TO, 0.0);
		
		if (center == null) {
			this.minX = -radius;
			this.minY = -radius;
			this.maxX =  radius;
			this.maxY =  radius;
		} else {
			this.minX = center.x - radius;
			this.minY = center.y - radius;
			this.maxX = center.x + radius;
			this.maxY = center.y + radius;
		}
	}
	
	/**
	 * Copy constructor.
	 * @param aabb the {@link AABB} to copy
	 * @since 3.1.1
	 */
	public AABB(AABB aabb) {
		this.minX = aabb.minX;
		this.minY = aabb.minY;
		this.maxX = aabb.maxX;
		this.maxY = aabb.maxY;
	}
	
	/* (non-Javadoc)
	 * @see org.dyn4j.Copyable#copy()
	 */
	public AABB copy() {
		return new AABB(this);
	}
	
	/**
	 * Sets this AABB to a degenerate zero AABB.
	 * @since 4.1.0
	 */
	public void zero() {
		this.minX = 0;
		this.maxX = 0;
		this.minY = 0;
		this.maxY = 0;
	}
	
	/**
	 * Sets this aabb to the given aabb's value and returns
	 * this AABB.
	 * @param aabb the aabb to copy
	 * @return {@link AABB}
	 * @since 3.2.5
	 */
	public AABB set(AABB aabb) {
		this.minX = aabb.minX;
		this.minY = aabb.minY;
		this.maxX = aabb.maxX;
		this.maxY = aabb.maxY;
		return this;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("AABB[Min=")
		.append("(")
		.append(this.minX)
		.append(", ")
		.append(this.minY)
		.append(")")
		.append("|Max=")
		.append("(")
		.append(this.maxX)
		.append(", ")
		.append(this.maxY)
		.append(")")
		.append("]");
		return sb.toString();
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		// have to do this because Double.hashcode is Java 8
		temp = Double.doubleToLongBits(this.maxX);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(this.maxY);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(this.minX);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(this.minY);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (obj == null) return false;
		if (this == obj) return true;
		if (obj instanceof AABB) {
			AABB other = (AABB) obj;
			return this.maxX == other.maxX &&
					this.minX == other.minX &&
					this.maxY == other.maxY &&
					this.minY == other.minY;
		}
		return false;
	}
	
	/* (non-Javadoc)
	 * @see org.dyn4j.geometry.Translatable#translate(double, double)
	 */
	@Override
	public void translate(double x, double y) {
		this.minX += x;
		this.minY += y;
		this.maxX += x;
		this.maxY += y;
	}
	
	/* (non-Javadoc)
	 * @see org.dyn4j.geometry.Translatable#translate(org.dyn4j.geometry.Vector2)
	 */
	@Override
	public void translate(Vector2 translation) {
		translate(translation.x, translation.y);
	}
	
	/**
	 * Returns a new AABB of this AABB translated by the
	 * given translation amount.
	 * @param translation the translation
	 * @return AABB
	 * @since 3.1.1
	 */
	public AABB getTranslated(Vector2 translation) {
		return new AABB(
				this.minX + translation.x,
				this.minY + translation.y,
				this.maxX + translation.x,
				this.maxY + translation.y);
	}
	
	/**
	 * Returns the width of this {@link AABB}.
	 * @return double
	 * @since 3.0.1
	 */
	public double getWidth() {
		return this.maxX - this.minX;
	}
	
	/**
	 * Returns the height of this {@link AABB}.
	 * @return double
	 * @since 3.0.1
	 */
	public double getHeight() {
		return this.maxY - this.minY;
	}
	
	/**
	 * Returns the perimeter of this {@link AABB}.
	 * @return double
	 */
	public double getPerimeter() {
		return 2 * (this.maxX - this.minX + this.maxY - this.minY);
	}
	
	/**
	 * Returns the area of this {@link AABB};.
	 * @return double
	 */
	public double getArea() {
		return (this.maxX - this.minX) * (this.maxY - this.minY);
	}
	
	/**
	 * Performs a union of this {@link AABB} and the given {@link AABB} placing
	 * the result of the union into this {@link AABB} and then returns
	 * this {@link AABB}
	 * @param aabb the {@link AABB} to union
	 * @return {@link AABB}
	 */
	public AABB union(AABB aabb) {
		this.minX = Math.min(this.minX, aabb.minX);
		this.minY = Math.min(this.minY, aabb.minY);
		this.maxX = Math.max(this.maxX, aabb.maxX);
		this.maxY = Math.max(this.maxY, aabb.maxY);
		return this;
	}

	/**
	 * Performs a union of the given {@link AABB}s and places the result
	 * into this {@link AABB} and then returns this {@link AABB}.
	 * @param aabb1 the first {@link AABB} to union
	 * @param aabb2 the second {@link AABB} to union
	 * @return {@link AABB}
	 * @since 4.0.0
	 */
	public AABB union(AABB aabb1, AABB aabb2) {
		this.minX = Math.min(aabb1.minX, aabb2.minX);
		this.minY = Math.min(aabb1.minY, aabb2.minY);
		this.maxX = Math.max(aabb1.maxX, aabb2.maxX);
		this.maxY = Math.max(aabb1.maxY, aabb2.maxY);
		return this;
	}
	
	/**
	 * Performs a union of this {@link AABB} and the given {@link AABB} returning
	 * a new {@link AABB} containing the result.
	 * @param aabb the {@link AABB} to union
	 * @return {@link AABB} the resulting union
	 */
	public AABB getUnion(AABB aabb) {
		return this.copy().union(aabb);
	}
	
	/**
	 * Performs the intersection of this {@link AABB} and the given {@link AABB} placing
	 * the result into this {@link AABB} and then returns this {@link AABB}.
	 * <p>
	 * If the given {@link AABB} does not overlap this {@link AABB}, this {@link AABB} is
	 * set to a zero {@link AABB}.
	 * @param aabb the {@link AABB} to intersect
	 * @return {@link AABB}
	 * @since 3.1.1
	 */
	public AABB intersection(AABB aabb) {
		this.minX = Math.max(this.minX, aabb.minX);
		this.minY = Math.max(this.minY, aabb.minY);
		this.maxX = Math.min(this.maxX, aabb.maxX);
		this.maxY = Math.min(this.maxY, aabb.maxY);
		
		// check for a bad AABB
		if (this.minX > this.maxX || this.minY > this.maxY) {
			// the two AABBs were not overlapping
			// set this AABB to a degenerate one
			this.minX = 0.0;
			this.minY = 0.0;
			this.maxX = 0.0;
			this.maxY = 0.0;
		}
		
		return this;
	}
	
	/**
	 * Performs the intersection of the given {@link AABB}s and places
	 * the result into this {@link AABB} and then returns this {@link AABB}.
	 * <p>
	 * If the given {@link AABB}s do not overlap, this {@link AABB} is
	 * set to a zero {@link AABB}.
	 * @param aabb1 the first {@link AABB} to intersect
	 * @param aabb2 the second {@link AABB} to intersect
	 * @return {@link AABB}
	 * @since 4.0.0
	 */
	public AABB intersection(AABB aabb1, AABB aabb2) {
		this.minX = Math.max(aabb1.minX, aabb2.minX);
		this.minY = Math.max(aabb1.minY, aabb2.minY);
		this.maxX = Math.min(aabb1.maxX, aabb2.maxX);
		this.maxY = Math.min(aabb1.maxY, aabb2.maxY);
		
		// check for a bad AABB
		if (this.minX > this.maxX || this.minY > this.maxY) {
			// the two AABBs were not overlapping
			// set this AABB to a degenerate one
			this.minX = 0.0;
			this.minY = 0.0;
			this.maxX = 0.0;
			this.maxY = 0.0;
		}
		
		return this;
	}
	
	/**
	 * Performs the intersection of this {@link AABB} and the given {@link AABB} returning
	 * the result in a new {@link AABB}.
	 * <p>
	 * If the given {@link AABB} does not overlap this {@link AABB}, a zero {@link AABB} is
	 * returned.
	 * @param aabb the {@link AABB} to intersect
	 * @return {@link AABB}
	 * @since 3.1.1
	 */
	public AABB getIntersection(AABB aabb) {
		return this.copy().intersection(aabb);
	}
	
	/**
	 * Expands this {@link AABB} by half the given expansion in each direction and
	 * then returns this {@link AABB}.
	 * <p>
	 * The expansion can be negative to shrink the {@link AABB}.  However, if the expansion is
	 * greater than the current width/height, the {@link AABB} can become invalid.  In this 
	 * case, the AABB will become a degenerate AABB at the mid point of the min and max for 
	 * the respective coordinates.
	 * @param expansion the expansion amount
	 * @return {@link AABB}
	 */
	public AABB expand(double expansion) {
		double e = expansion * 0.5;
		this.minX -= e;
		this.minY -= e;
		this.maxX += e;
		this.maxY += e;
		// we only need to verify the new aabb if the expansion
		// was inwardly
		if (expansion < 0.0) {
			// if the aabb is invalid then set the min/max(es) to
			// the middle value of their current values
			if (this.minX > this.maxX) {
				double mid = (this.minX + this.maxX) * 0.5;
				this.minX = mid;
				this.maxX = mid;
			}
			if (this.minY > this.maxY) {
				double mid = (this.minY + this.maxY) * 0.5;
				this.minY = mid;
				this.maxY = mid;
			}
		}
		return this;
	}

	/**
	 * Returns a new {@link AABB} of this AABB expanded by half the given expansion
	 * in both the x and y directions.
	 * <p>
	 * The expansion can be negative to shrink the {@link AABB}.  However, if the expansion is
	 * greater than the current width/height, the {@link AABB} can become invalid.  In this 
	 * case, the AABB will become a degenerate AABB at the mid point of the min and max for 
	 * the respective coordinates.
	 * @param expansion the expansion amount
	 * @return {@link AABB}
	 * @since 3.1.1
	 */
	public AABB getExpanded(double expansion) {
		return this.copy().expand(expansion);
	}
	
	/**
	 * Returns true if the given {@link AABB} and this {@link AABB} overlap.
	 * @param aabb the {@link AABB} to test
	 * @return boolean true if the {@link AABB}s overlap
	 */
	public boolean overlaps(AABB aabb) {
		return this.minX <= aabb.maxX &&
				this.maxX >= aabb.minX &&
				this.minY <= aabb.maxY &&
				this.maxY >= aabb.minY;
	}
	
	/**
	 * Returns true if the given {@link AABB} is contained within this {@link AABB}.
	 * @param aabb the {@link AABB} to test
	 * @return boolean
	 */
	public boolean contains(AABB aabb) {
		return this.minX <= aabb.minX &&
				this.maxX >= aabb.maxX &&
				this.minY <= aabb.minY &&
				this.maxY >= aabb.maxY;
	}
	
	/**
	 * Returns true if the given point is contained within this {@link AABB}.
	 * @param point the point to test
	 * @return boolean
	 * @since 3.1.1
	 */
	public boolean contains(Vector2 point) {
		return this.contains(point.x, point.y);
	}
	
	/**
	 * Returns true if the given point's coordinates are contained within this {@link AABB}.
	 * @param x the x coordinate of the point
	 * @param y the y coordinate of the point
	 * @return boolean
	 * @since 3.1.1
	 */
	public boolean contains(double x, double y) {
		return this.minX <= x &&
				this.maxX >= x &&
				this.minY <= y &&
				this.maxY >= y;
	}
	
	/**
	 * Returns true if this {@link AABB} is degenerate.
	 * <p>
	 * A degenerate {@link AABB} is one where its min and max x or y
	 * coordinates are equal.
	 * @return boolean
	 * @since 3.1.1
	 */
	public boolean isDegenerate() {
		return this.minX == this.maxX || this.minY == this.maxY;
	}
	
	/**
	 * Returns true if this {@link AABB} is degenerate given
	 * the specified error.
	 * <p>
	 * An {@link AABB} is degenerate given some error if
	 * max - min &lt;= error for either the x or y coordinate.
	 * @param error the allowed error
	 * @return boolean
	 * @since 3.1.1
	 * @see #isDegenerate()
	 */
	public boolean isDegenerate(double error) {
		return Math.abs(this.maxX - this.minX) <= error || Math.abs(this.maxY - this.minY) <= error;
	}
	
	/**
	 * Returns the center of the AABB.
	 * @return {@link Vector2}
	 * @since 4.0.0
	 */
	public Vector2 getCenter() {
		return new Vector2(
				this.minX + (this.maxX - this.minX) * 0.5,
				this.minY + (this.maxY - this.minY) * 0.5);
	}
	
	/**
	 * Returns the minimum x extent.
	 * @return double
	 */
	public double getMinX() {
		return this.minX;
	}
	
	/**
	 * Returns the maximum x extent.
	 * @return double
	 */
	public double getMaxX() {
		return this.maxX;
	}
	
	/**
	 * Returns the maximum y extent.
	 * @return double
	 */
	public double getMaxY() {
		return this.maxY;
	}
	
	/**
	 * Returns the minimum y extent.
	 * @return double
	 */
	public double getMinY() {
		return this.minY;
	}
}
