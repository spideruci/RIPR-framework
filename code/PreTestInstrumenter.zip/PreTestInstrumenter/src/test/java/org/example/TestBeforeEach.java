package org.example;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//
//import static org.junit.jupiter.api.Assertions.assertTrue;
//
public class TestBeforeEach {

//    @AfterAll
//    public static void doAfterAll() {
//        System.err.println("afterAll");
//    }
//
//
//    @BeforeAll
//    public static void doBeforeAll() {
//        System.err.println("beforeAll");
//    }
//    @Test
//    public void test1() {
//
//    }

}
