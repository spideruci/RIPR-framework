import com.thoughtworks.xstream.XStream;
import org.apache.commons.lang3.StringUtils;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

public class InstrumentationUtils {

    public static Object[] _states;
    public static Set<String> processedStaticFields = new HashSet<>();

    public static List<Object> afterAllStates;

    public static XStream xstream = new XStream();
    static {
        xstream.setMode(XStream.ID_REFERENCES);
        xstream.ignoreUnknownElements();
    }

    static {
        try (BufferedReader reader = new BufferedReader(new FileReader("target/staticFields.txt"))) {
            String line;

            while ((line = reader.readLine()) != null) {
                //filter JCL classes out
                String[] lineSplits = line.split(" ");
                if (!lineSplits[1].startsWith("java/") && !lineSplits[1].startsWith("javax/")) {
                    String className = lineSplits[1];
                    className = className.replace("/", ".");
                    String fieldName = lineSplits[2];
                    processedStaticFields.add(className + " " + fieldName);
                }
            }
        } catch (Exception e) {
            System.err.println("Error: wrong in processing static fields in BeforeAll");
            e.printStackTrace();
        }
    }


    //if the mutation has been executed
    public static AtomicLong eProbeMR = new AtomicLong(0);
    //how many times the methods have been visited before the mutation is executed
    public static AtomicLong NeProbeMR = new AtomicLong(0);
    //How many times the methods have been visited globally.
    public static AtomicLong NgProbeMR = new AtomicLong(0);
    //How many times the mutation has been executed in total.
    public static AtomicLong NProbeMR = new AtomicLong(0);
    //if the states have been dumped?
    public static AtomicLong dumpedMR = new AtomicLong(0);

    public static AtomicLong NProbeNMR = new AtomicLong(0);

    public static AtomicLong dumpedNMR = new AtomicLong(0);

    public static AtomicLong whichTest = new AtomicLong(0);

    public static AtomicLong loopN = new AtomicLong(0);

    public static void clearStatic() throws ClassNotFoundException, NoSuchFieldException, IllegalAccessException {

        Class clazz = Class.forName("org.apache.commons.text.lookup.ConstantStringLookup");
        Field modifiersField = Field.class.getDeclaredField("modifiers");
        modifiersField.setAccessible(true);
        Field field = clazz.getDeclaredField("CONSTANT_CACHE");
        modifiersField.setInt(field, field.getModifiers() & ~Modifier.FINAL);
        field.setAccessible(true);
        field.set(null, new ConcurrentHashMap<>());
    }


    public static void initializeProbesPerTest() {
        //MRProbes
        eProbeMR.set(0);
        NeProbeMR.set(0);
        NgProbeMR.set(0);
        NProbeMR.set(0);
        dumpedMR.set(0);
        //NMRProbes
        NProbeNMR.set(0);
        dumpedNMR.set(0);

        if (isNMRState()) {
            setWhichTest();
            setLoopN();
        }
    }

    public static void dumpProbesPerTest() {
        if (isMRState()) {
            clearFile("target/MR.txt");
            String MR_info = eProbeMR.toString() + " " + NeProbeMR.toString() +
                    " " + NgProbeMR.toString() + " " + NProbeMR.toString() +
                    " " + dumpedMR.toString();
            addOneLine(MR_info, "target/MR.txt");
        } else if (isNMRState()) {
            clearFile("target/NMR.txt");
            String NMR_info = NProbeNMR.toString() + " " + dumpedNMR.toString();
            addOneLine(NMR_info, "target/NMR.txt");
        }
    }

    public static void dumpStatic() {

        Object[] obArray = new Object[processedStaticFields.size()];
        int i = 0;
        try {
            for (String content:processedStaticFields) {
                String[] content_splits = content.split(" ");
                String className = content_splits[0];
                String fieldName = content_splits[1];
                Class<?> clazz = Class.forName(className);
                Field field = clazz.getDeclaredField(fieldName);
                field.setAccessible(true);
                Object value = field.get(null);
                obArray[i] = value;
                i++;
            }
        } catch (Exception e) {
            System.err.println("Error: wrong in using reflection in BeforeAll");
//            e.printStackTrace();
        }

        try {
            String path = "target/staticFields/" + System.nanoTime() +  ".xml";
            FileWriter fw = new FileWriter(path);
            xstream.toXML(obArray,fw);
        } catch (Exception e) {
            System.err.println("Error: wrong in using Xstream in BeforeAll");
//            e.printStackTrace();
        }
    }

    public static boolean isMRState() {
        String res = readOneLine("target/GlobalStates.txt");
        if (res.equals("1")) {
            return true;
        }
        return false;
    }

    public static boolean isNMRState() {
        String res = readOneLine("target/GlobalStates.txt");
        if (res.equals("0")) {
            return true;
        }
        return false;
    }



    /**
     * invoked if the mutation is going to be executed
     */
    public static void setEProbeMR() {
        eProbeMR.set(1);
    }

    public static void visitNEProbeMR() {
        if (eProbeMR.get() == 0) {
            NeProbeMR.incrementAndGet();
        }
    }

    public static void visitNGProbeMR() {
        NgProbeMR.incrementAndGet();
    }

    public static void visitNProbeMR() {
        NProbeMR.incrementAndGet();
    }

    public static void setDumpedMR() {
        dumpedMR.set(1);
    }




    /**
     * if the states should be dumped
     * 1: mutation executed, 2: states haven't been dumped, 3: current visit
     * @return 0 should be dumped
     */
    public static int shouldDumpStateForMR() {
        if (eProbeMR.get() == 1 && dumpedMR.get() != 1 && NeProbeMR.get() == NgProbeMR.get()) {
            return 0;
        }
        return 1;
    }


    public static void setLoopN() {
        String MRInfo = readLineFromFile("target/MRs.txt", whichTest.intValue());
        if (MRInfo == null) {
            System.err.println("MRinfo is null");
            return;
        }
        String[] results = MRInfo.split(" ");
        loopN.set(Long.parseLong(results[1]));
    }

    public static void setWhichTest() {
        whichTest.set(Long.valueOf(readOneLine("target/WhichTest.txt")));
    }

    /**
     * if the states should be dumped for NMR
     * 1. states hasn't been dumped 2. NprobeNMR == NeProbeMR
     * @return
     */
    public static int shouldDumpStateForNMR() {
        if (dumpedNMR.get() == 0 && loopN.get() == NProbeNMR.get()) {
            return 0;
        }
        return 1;
    }

    public static void clearFile(String filePath) {
        checkExistsOrCreate(filePath);
        try {
            // Create a new FileWriter object that points to the text file
            FileWriter writer = new FileWriter(filePath);

            // Overwrite the contents of the text file with an empty string
            writer.write("");

            // Close the file and save the changes
            writer.close();
        } catch (IOException e) {
            // Handle the exception
        }
    }

    public static void checkExistsOrCreate(String filePath) {
        File targetFile = new File(filePath);
        if (!targetFile.exists()) {
            try {
                targetFile.createNewFile();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }

    public static synchronized void addOneLine(String info, String filePath) {
        File targetFile = new File(filePath);
        // Check if the file exists, and create it if it doesn't
        checkExistsOrCreate(filePath);

        // Append a line to the end of the file
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(targetFile, true))) {
            bw.write(info);
            bw.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public static String readOneLine(String filePath) {
        try {
            // Create a new FileReader object that points to the text file
            FileReader reader = new FileReader(filePath);

            // Wrap the FileReader object in a BufferedReader object
            BufferedReader bufferedReader = new BufferedReader(reader);

            // Read a single line of text from the file
            String line = bufferedReader.readLine();

            // Close the file and release any resources associated with it
            bufferedReader.close();
            return line;
        } catch (IOException e) {
            // Handle the exception
        }
        return null;
    }


    public static synchronized void dumpObjectUsingXml(Object o,String filename,String parentFolder, String secondFolder){
        //Dump xml output to xmlOutput/testClassName/testMethodName/variableName nanotime.xml

        String base = "target/xmlOutput"+File.separator+parentFolder+File.separator+secondFolder;
        try{File directory = new File(base);
            directory.mkdirs();
        }catch(Exception e){
            addOneLine("fail to create folder","target/xmlOutput/errInfo");
        }

        try{
            String path = base + File.separator + filename + ".xml";
            FileWriter fw = new FileWriter(path);
            xstream.toXML(o,fw);
        }catch(Throwable t){
            String info = "";
            for (StackTraceElement ste: t.getStackTrace()) {
                info = info + ste.getFileName() + " " + ste.getMethodName() + " " + ste.getLineNumber() + "\n";
            }
            addOneLine("ha:there is something wrong when using XStream, the reason is: \n"
                    + t.getMessage() + "\n" + info, "target/XStreamError.txt");
            t.printStackTrace();
            System.err.println("XStream failure");
        }
        //redundant but works
        dumpedMR.set(1);
        dumpedNMR.set(1);
    }


    public static void visitNProbeNMR() {
        NProbeNMR.incrementAndGet();
    }

    public static void setDumpedNMR() {
        dumpedNMR.set(1);
    }


    public static String readLineFromFile(String fileName, int lineNumber) {
        String line = null;
        lineNumber = lineNumber + 1;
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            for (int i = 0; i < lineNumber; i++) {
                line = reader.readLine();
            }
        } catch (IOException e) {
            System.err.println("An error occurred while reading the file: " + e.getMessage());
        }
        return line;
    }

}
