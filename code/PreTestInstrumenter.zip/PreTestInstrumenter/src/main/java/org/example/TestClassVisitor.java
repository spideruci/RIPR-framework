package org.example;

import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

public class TestClassVisitor extends ClassVisitor {
    private String className;
    private boolean isStatic;
    public TestClassVisitor(ClassVisitor cv) {
        super(Opcodes.ASM9, cv);
        this.className = null;
        this.isStatic = false;
    }

    @Override
    public void visit(int version, int access, String name, String signature, String superName, String[] interfaces) {
        this.className = name;
        super.visit(version, access, name, signature, superName, interfaces);
    }

    @Override
    public MethodVisitor visitMethod(int access, String name, String descriptor, String signature, String[] exceptions) {
        MethodVisitor mv = this.cv.visitMethod(access, name, descriptor, signature, exceptions);
        if (this.className.startsWith("inst/InstrumentationUtils") | name.equals("<clinit>")) {
            return mv;
        }

        if (this.className.startsWith("org/jsoup/integration")) {
            return mv;
        }
        //for commons beanutils
        if(!this.className.contains("TestCase") && this.className.contains("Bean")) {
            return mv;
        }

        return new TestMethodVisitor(Opcodes.ASM9,mv, name);
    }

}