package org.example;

import org.objectweb.asm.AnnotationVisitor;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Label;
import java.util.HashSet;
import java.util.Set;



public class TestMethodVisitor extends MethodVisitor {


    private boolean isBeforeAll;

    private boolean isAfterAll;

    private String methodName;



    protected TestMethodVisitor(int api, MethodVisitor methodVisitor, String methodName) {
        super(api, methodVisitor);
        this.methodName = methodName;

    }

    /**
     * initailize probes only in beforeall
     */

    @Override
    public void visitCode() {
        super.visitCode();
        if (this.isBeforeAll) {


            mv.visitTypeInsn(Opcodes.NEW, "java/util/LinkedList");
            mv.visitInsn(Opcodes.DUP);
            mv.visitMethodInsn(Opcodes.INVOKESPECIAL, "java/util/LinkedList", "<init>", "()V", false);
            mv.visitFieldInsn(Opcodes.PUTSTATIC, "inst/InstrumentationUtils", "afterAllStates", "Ljava/util/List;");

//            mv.visitFieldInsn(Opcodes.GETSTATIC, "InstrumentationUtils", "afterAllStates", "Ljava/util/List;");
//            mv.visitLdcInsn("daskldj");
//            mv.visitMethodInsn(Opcodes.INVOKEINTERFACE, "java/util/List", "add", "(Ljava/lang/Object;)Z", true);
//            mv.visitInsn(Opcodes.POP);

//            0: new           #2                  // class java/util/LinkedList
//            3: dup
//            4: invokespecial #3                  // Method java/util/LinkedList."<init>":()V
//            7: putstatic     #4                  // Field afterAllStates:Ljava/util/List;
//            10: getstatic     #4                  // Field afterAllStates:Ljava/util/List;
//            13: ldc           #5                  // String daskldj
//            15: invokeinterface #6,  2            // InterfaceMethod java/util/List.add:(Ljava/lang/Object;)Z
//            20: pop

        }
    }

    /** this only works for constructors of a test class **/


    @Override
    public void visitInsn(int opcode) {
        if (this.isAfterAll && isReturn(opcode)) {
            //TODO
            mv.visitFieldInsn(Opcodes.GETSTATIC, "inst/InstrumentationUtils", "afterAllStates", "Ljava/util/List;");

            //dump the object array using XStream
            this.mv.visitLdcInsn("AfterAll");
            this.mv.visitLdcInsn("AfterAll");
            this.mv.visitLdcInsn("AfterAll");
            this.mv.visitMethodInsn(Opcodes.INVOKESTATIC, "inst/InstrumentationUtils",
                    "dumpObjectUsingXml", "(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", false);

            this.mv.visitMethodInsn(Opcodes.INVOKESTATIC, "inst/InstrumentationUtils",
                    "dumpStaticInAfterAll", "()V", false);
        }
        super.visitInsn(opcode);
    }

    /**
     * add return value from any method invocation to the object list
     * @param opcode
     * @param owner
     * @param name
     * @param descriptor
     * @param isInterface
     */

    @Override
    public void visitMethodInsn(int opcode, String owner, String name, String descriptor, boolean isInterface) {
        super.visitMethodInsn(opcode, owner, name, descriptor, isInterface);

        String returnType = AsmUtils.getReturnType(descriptor);
//        if (owner.startsWith("org/junit/") || owner.startsWith("org/assertj")) {
//            return;
//        }
//         method invocation without return values (constructor)

        //for commons-beanutils
        if (owner.startsWith("by.stub")) {
            return;
        }
        if (owner.startsWith("javax/script") || owner.startsWith("java/lang/Thread") || owner.startsWith("java/util/concurrent") || owner.startsWith("org/h2")) {
            return;
        }
        // doesn't keep track of init under init

        if (name.equals("<init>")  && !methodName.equals("<init>") ) {//
            visitInsn(Opcodes.DUP);
            mv.visitFieldInsn(Opcodes.GETSTATIC, "inst/InstrumentationUtils", "afterAllStates", "Ljava/util/List;");
            visitInsn(Opcodes.SWAP);
            mv.visitMethodInsn(Opcodes.INVOKEINTERFACE, "java/util/List", "add","(Ljava/lang/Object;)Z", true);
            mv.visitInsn(Opcodes.POP);
            return;
        }

        // method invocation with return values
        // 1. owner.contains("jfree")
        // 2. owner.contains("unix4j")
        // 3. owner.contains("dyn4j")
        // 4. && owner.contains("text") && owner.contains("commons")
        // 5. && owner.contains("csv") && owner.contains("commons")
        // owner.contains("jline")
        // owner.contains("cdk")
        // & owner.contains("validator")
        //owner.contains("spotify")
        // && owner.contains("cli") && owner.contains("commons")
        //&& owner.contains("codec") && owner.contains("commons")
        if ((!returnType.equals("V") && owner.contains("money"))  && owner.contains("joda")) {//    && owner.contains("cdk")            && name.equals("mock") && name.contains("EnhancerBy")  // && !returnType.startsWith("Lorg.junit") && !returnType.startsWith("Lorg.assertj")    && !returnType.startsWith("Ljava/") && !returnType.startsWith("Ljavax/")
            System.err.println(owner + " " + returnType);
            // For Non-long/double type return value
            if (!returnType.equals("D") && !returnType.equals("J")) {
                visitInsn(Opcodes.DUP);
                mv.visitFieldInsn(Opcodes.GETSTATIC, "inst/InstrumentationUtils", "afterAllStates", "Ljava/util/List;");
                visitInsn(Opcodes.SWAP);
                //coxpy and put the return value/reference onto the operand stack
            } else {
                visitInsn(Opcodes.DUP2);
                this.mv.visitFieldInsn(Opcodes.GETSTATIC,"inst/InstrumentationUtils","afterAllStates","Ljava/util/List;");
                visitInsn(Opcodes.DUP_X2);
                visitInsn(Opcodes.POP);
            }
            if (AsmUtils.isPrimitive(returnType)) {
                this.mv.visitMethodInsn(Opcodes.INVOKESTATIC,
                        "java/lang/" + AsmUtils.desToType(returnType),
                        "valueOf",
                        "(" + returnType + ")Ljava/lang/" + AsmUtils.desToType(returnType) + ";",
                        false);
            }

            mv.visitMethodInsn(Opcodes.INVOKEINTERFACE, "java/util/List", "add","(Ljava/lang/Object;)Z", true);
            mv.visitInsn(Opcodes.POP);
        }
    }

    @Override
    public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) {
        if (descriptor.endsWith("/BeforeAll;")) {
            this.isBeforeAll = true;
        } else if (descriptor.endsWith("/AfterAll;")){
            this.isAfterAll = true;
        }
        return super.visitAnnotation(descriptor, visible);
    }

    public static Set<Integer> returnStm = new HashSet<Integer>();

    static {
        // initialze returnStm sets
        returnStm.add(Opcodes.IRETURN);
        returnStm.add(Opcodes.FRETURN);
        returnStm.add(Opcodes.ARETURN);
        returnStm.add(Opcodes.LRETURN);
        returnStm.add(Opcodes.RETURN);
        returnStm.add(Opcodes.DRETURN);
    }

    public static Boolean isReturn(int op) {
        if (returnStm.contains(op)) {
            return true;
        }
        return false;
    }
}


