package org.example;

import org.objectweb.asm.ClassWriter;

public class MyClassWriter extends ClassWriter {
    public MyClassWriter(int flags) {
        super(flags);
    }

    @Override
    protected String getCommonSuperClass(String type1, String type2) {
        // your implementation here
//        System.err.println(type1);
//        System.err.println(type2);
//        System.err.println("**********");
//        return "java/lang/Object";

//        if (type1.startsWith("org/apache/commons") || type2.startsWith("org/apache/commons")) {
//            return "java/lang/Object";
//        }
        return super.getCommonSuperClass(type1, type2);

    }
}
