package org.example;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
public class MyTest {

    private static final Character[] BINARY = {'0', '1'};

    @Test
    public void doSomething() {
        assertDoesNotThrow(() -> new Example().doSomething());
    }

    @AfterAll
    public static void doAfterAll() {
        System.err.println("afterAll");
    }

    @BeforeAll
    public static void doBeforeAll() {
        System.err.println("beforeAll");
    }

}
