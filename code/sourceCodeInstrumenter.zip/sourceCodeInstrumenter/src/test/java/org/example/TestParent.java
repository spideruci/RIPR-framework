package org.example;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestParent {
//
//    public static int staticX;
//    public static TestParent staticY;
//
//    @AfterAll
//    public static void doAfterAll() {
//        System.err.println("afterAll");
//    }
//
//
//
//    @BeforeAll
//    public static void doBeforeAll() {
//        System.err.println("beforeAll");
//    }
//
//    TestParent() {
//
//    }
//
//    @Test
//    public void test1() {
//        assertEquals(true,true);
//    }

}
