package org.example;

public class OtherClass {
    public int x = 3;
}
