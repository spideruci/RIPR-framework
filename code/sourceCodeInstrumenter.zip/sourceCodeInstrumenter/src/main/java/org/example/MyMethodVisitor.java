package org.example;

import org.objectweb.asm.Label;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;

import java.util.List;
import java.util.Set;


public class MyMethodVisitor extends MethodVisitor {
    public MyMethodVisitor(int api, MethodVisitor methodVisitor) {
        super(api, methodVisitor);
    }

    /**
     * invoke InstrumentationUtils
     */
    @Override
    public void visitCode() {
        this.mv.visitMethodInsn(Opcodes.INVOKESTATIC, "inst/InstrumentationUtils",
                "updateN", "()V", false);;
    }





}
