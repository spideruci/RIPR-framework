# This project is for instrumenting test cases

## what is this project doing?
copy the value (one or two slots) on the top of the operand stack and add it to the list, whenever the current bytecode instruction is:

1. invocation of a method with a value return
2. store (such as ASTORE, ISTORE, LSTORE, etc)
3. getStatic
4. ………………
5. The instrumentation is after each appropriate byte code instruction

## Project Requirements:
1. Junit 5 (Junit 4 not supported)
2. single module maven project
3. Test classes constructors should not be explicitly specified (use ``@Before` instead)
4Test classes shouldn't have inheritance. If it has, transform it manually.
### dependencies
```
    <dependencies>
        <dependency>
            <groupId>com.thoughtworks.xstream</groupId>
            <artifactId>xstream</artifactId>
            <version>1.4.19</version>
        </dependency>
        <dependency>
            <groupId>org.ow2.asm</groupId>
            <artifactId>asm</artifactId>
            <version>9.4</version>
        </dependency>
        <dependency>
            <groupId>org.junit.jupiter</groupId>
            <artifactId>junit-jupiter</artifactId>
            <version>5.X.X</version>
            <scope>test</scope>
        </dependency>
        <dependency>
            <groupId>org.apache.commons</groupId>
            <artifactId>commons-lang3</artifactId>
            <version>3.12.0</version>
        </dependency>
    </dependencies>
```

## How things are done?
### Which files will be instrumented?
1. all files target/test-classes AND,
2. file name starting with ``Test`` or ending with ``Test``
