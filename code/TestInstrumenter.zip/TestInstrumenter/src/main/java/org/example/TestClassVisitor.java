package org.example;

import org.objectweb.asm.*;

public class TestClassVisitor extends ClassVisitor {
    private String className;

    private String superName;

    private boolean isStaticClass;


    public TestClassVisitor(ClassVisitor cv) {
        super(Opcodes.ASM9, cv);
        this.className = null;
//        TestMethodVisitor.hasAddBeforeAll = false;
    }

    @Override
    public void visit(int version, int access, String name, String signature, String superName, String[] interfaces) {
        this.className = name;
        if(className.contains("$")) {
            System.err.println("inner: " + name);
        }
//        System.err.println(name + access);
//        if ((access & Opcodes.ACC_STATIC) != 0) {
//            System.err.println("isStaticClass");
//            this.isStaticClass = true;
//        }
        this.superName = superName;
        super.visit(version, access, name, signature, superName, interfaces);
    }

    @Override
    public FieldVisitor visitField(int access, String name, String descriptor, String signature, Object value) {
        return super.visitField(access, name, descriptor, signature, value);
    }

    @Override
    public MethodVisitor visitMethod(int access, String name, String descriptor, String signature, String[] exceptions) {
        MethodVisitor mv = this.cv.visitMethod(access, name, descriptor, signature, exceptions);

        //skip inner class
        if (className.contains("$")) {
            System.err.println("inner class method");
            return mv;
        }
//        if (this.isStaticClass) {
//            System.err.println("skipped static class");
//            return mv;
//        }
//        if (name.equals("<init>")) {
//            TestMethodVisitor.hasSeenSuper = false;
//        }
//        // only for commons-lang
//        if (this.className.contains("$RunTest")) {
//            return mv;
//        }
//        // only for joda-money
//        if (this.className.contains("$IOAppendable")) {
//            return mv;
//        }


        boolean isStatic = (access & Opcodes.ACC_STATIC) != 0;

        int sizeParas = 0;
        for (Type t : Type.getArgumentTypes(descriptor)) {
            if (t.toString().equals("J") || t.toString().equals("D")) {
                sizeParas += 2;
            } else {
                sizeParas += 1;
            }
        }
        //apache-wicket
//        boolean isPara = name.equals("provideLTRtag")
//                || name.equals("provideRTLtags")
//                || name.equals("provideLTRtags")
//                || name.equals("provideRTLtags")
//                || name.equals("parameters");

        // commmons-codec
//        boolean isPara = name.equals("data") || name.equals("factory");

        //imglib2
//        boolean isPara = name.equals("getData");

        //joda-money
//        boolean isPara = name.equals("data_provider")
//                || name.equals("data_appendAmount")
//                || name.equals("data_appendAmountLocalized")
//                || name.equals("data_appendAmountExtendedGrouping")
//                || name.equals("data_appendAmount_MoneyAmountStyle");

        // 3. dyn4j "data"
//        boolean isPara = name.equals("data");

        // 4. commons-text
//        boolean isPara = name.equals("parameters");
        // 5. commons-csv
//        boolean isPara = name.equals("duplicateHeaderAllowsMissingColumnsNamesData")
//                || name.equals("duplicateHeaderData")
//                || name.equals("generateData");
        //6. commons-codec
//        boolean isPara = name.equals("data")|| name.equals("factory");
        //7. joda-money
        boolean isPara = name.equals("data_appendAmountLocalized")
                || name.equals("data_appendAmountExtendedGrouping")
                || name.equals("data_appendAmount_MoneyAmountStyle")
                || name.equals("data_appendAmount")
                || name.equals("data_parse");

        //commons-bcel
//        boolean isPara = name.equals("streamJarPath")
//                || name.equals("streamModulePath")
//                || name.equals("streamJavaHome")
//                || name.equals("streamJarEntryClassName")
//                || name.equals("streamModularRuntimeImage");

        // commons-jexl
//        boolean isPara = name.equals("data");
        // commons-compress
//        boolean isPara = name.equals("factory")
//                || name.equals("data");

        //commons-lang
//        boolean isPara = name.equals("lastIndexWithStandardCharSequence")
//                || name.equals("getAvailableLocales")
//                || name.equals("data")
//                || name.equals("dateParserParameters");

        //jsoup
//        boolean isPara = name.equals("testOutputSettings")
//                    || name.equals("provideEvaluators")
//                    || name.equals("provideArguments")
//                    || name.equals("afterEach") || name.equals("testFiles");

                // commons-csv
//        boolean isPara = name.equals("generateData")
//                || name.equals("duplicateHeaderAllowsMissingColumnsNamesData")
//                || name.equals("duplicateHeaderData");

        // jfreechart
        // no parameterized tests

        return new TestMethodVisitor(Opcodes.ASM9,mv,className, name, isStatic, cv, isPara,sizeParas, this.superName);
    }

}