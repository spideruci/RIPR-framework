package org.example;

import org.objectweb.asm.AnnotationVisitor;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Label;
import java.util.HashSet;
import java.util.Set;



public class TestMethodVisitor extends MethodVisitor {

    private String superName;
    private final Label start = new Label(),
            end = new Label(),
            handler = new Label(), handlerEnd = new Label(), finallyStart = new Label(), finallyEnd = new Label();
    private String className;

    private int sizeParas;
    public boolean hasTestAnnotation;

    public boolean paraMethod;
    private String methodName;
    private boolean isStatic;

    public static boolean hasAddBeforeAll;

    public static boolean hasSeenSuper;

    private boolean hasBeforeAll;

    private ClassVisitor cv;


    protected TestMethodVisitor(int api, MethodVisitor methodVisitor, String className, String methodName, boolean isStatic, ClassVisitor cv, boolean isPara, int sizeParas, String superName) {
        super(api, methodVisitor);
        this.className = className;
        this.hasTestAnnotation = isPara;
        this.methodName = methodName;
        this.isStatic = isStatic;
        this.cv = cv;
        this.paraMethod = isPara;
        this.sizeParas = sizeParas;
        this.superName = superName;
    }

    /**
     * initailize probes only in beforeall
     */

    @Override
    public void visitCode() {



        super.visitCode();
        if (this.hasBeforeAll) {
            this.mv.visitMethodInsn(Opcodes.INVOKESTATIC, "inst/InstrumentationUtils",
                        "initializeProbesPerTest", "()V", false);
            this.mv.visitMethodInsn(Opcodes.INVOKESTATIC, "inst/InstrumentationUtils",
                    "clearStatic", "()V", false);
            this.mv.visitMethodInsn(Opcodes.INVOKESTATIC, "inst/InstrumentationUtils",
                    "dumpStatic", "()V", false);
        }

        if ((shouldInstrument(methodName,className) && !methodName.equals("<init>")) || paraMethod) {
            visitLabel(start);
        }

    }

    /** this only works for constructors of a test class **/
    @Override
    public void visitMethodInsn(int opcode, String owner, String name, String descriptor, boolean isInterface) {
        super.visitMethodInsn(opcode, owner, name, descriptor, isInterface);
        // 1. test class 2: constructor 3: after super
        String[] tempNames = className.split("/");
        String cn = tempNames[tempNames.length-1];
        String[] myTemp = cn.split("$");
        cn = myTemp[myTemp.length-1];

        // constructors
        if (opcode == Opcodes.INVOKESPECIAL &&
                name.equals("<init>") &&
                (owner.equals(superName) || owner.equals(className)) &&
                (cn.startsWith("Test") || cn.endsWith("Test") || cn.contains("Test")) ) {
            visitLabel(start);
        }
//        if (cn.startsWith("Test") || cn.endsWith("Test")) {
//            if (opcode == Opcodes.INVOKESPECIAL && !hasSeenSuper) {// && methodName.equals("<init>")
//                hasSeenSuper = true;
//                visitLabel(start);
//            }
//        }
    }

    @Override
    public void visitEnd() {

        mv.visitEnd();
//        if ( !CheckBeforeAllClassVisitor.hasBeforeAll && !hasAddBeforeAll) {
//            hasAddBeforeAll = true;
//            addNewMethod(cv);
//        }

    }

    private void addNewMethod(ClassVisitor cv) {
        MethodVisitor mv = cv.visitMethod(Opcodes.ACC_PUBLIC + Opcodes.ACC_STATIC, "setUpBeforeAll", "()V", null, null);
        mv.visitAnnotation("Lorg/junit/jupiter/api/BeforeAll;",true);
        mv.visitCode();
        mv.visitMethodInsn(Opcodes.INVOKESTATIC, "inst/InstrumentationUtils",
                "initializeProbesPerTest", "()V", false);
        mv.visitMethodInsn(Opcodes.INVOKESTATIC, "inst/InstrumentationUtils",
                "clearStatic", "()V", false);
        mv.visitMethodInsn(Opcodes.INVOKESTATIC, "inst/InstrumentationUtils",
                "dumpStatic", "()V", false);

        mv.visitInsn(Opcodes.RETURN);
        mv.visitMaxs(0,0);
        mv.visitEnd();
    }

    @Override
    public void visitMaxs(int maxStack, int maxLocals) {
        String[] tempNames = className.split("/");
        String cn = tempNames[tempNames.length-1];
        String[] myTemp = cn.split("$");
        cn = myTemp[myTemp.length-1];

        // constructors

        if (shouldInstrument(this.methodName, this.className) || paraMethod ||
                (this.methodName.equals("<init>") &&
                        ((cn.startsWith("Test") || cn.endsWith("Test") || cn.contains("Test"))))) {

            visitLabel(end);
            visitJumpInsn(Opcodes.GOTO, handlerEnd);
            visitLabel(handler);
            // store the caught exception static/non-static methods
            if (this.isStatic) {
                mv.visitVarInsn(Opcodes.ASTORE, 0 + sizeParas);
            } else {
                mv.visitVarInsn(Opcodes.ASTORE, 1 + sizeParas);
            }
            //TODO: do something here
            this.mv.visitMethodInsn(Opcodes.INVOKESTATIC, "inst/InstrumentationUtils",
                    "dumpProbesPerTest", "()V", false);

            // re-throw the original Throwable object
            if (this.isStatic) {
                mv.visitVarInsn(Opcodes.ALOAD, 0 + sizeParas);
            } else {
                mv.visitVarInsn(Opcodes.ALOAD, 1 + sizeParas);
            }
            mv.visitInsn(Opcodes.ATHROW);
            visitLabel(handlerEnd);
            visitTryCatchBlock(start, end, handler, "java/lang/Throwable");
        }
        super.visitMaxs(maxStack, maxLocals);
    }

    private boolean shouldInstrument(String methodName, String className) {
        //static blocks, constructors
        String[] tempNames = className.split("/");
        String cn = tempNames[tempNames.length-1];
        String[] myTemp = cn.split("$");
        cn = myTemp[myTemp.length-1];
        if (hasTestAnnotation) {
            return true;
        }
        if (cn.startsWith("Test") || cn.endsWith("Test") || cn.contains("Test")) {
            if ( methodName.equals("<clinit>") || hasTestAnnotation ){ //|| methodName.equals("<init>")
                return true;
            }
        }
        return false;
    }

    @Override
    public void visitInsn(int opcode) {
        String[] tempNames = className.split("/");
        String cn = tempNames[tempNames.length-1];
        String[] myTemp = cn.split("$");
        cn = myTemp[myTemp.length-1];

        if ((shouldInstrument(this.methodName, this.className) && isReturn(opcode))||
                ((this.methodName.equals("<init>")
                        && (cn.startsWith("Test") || (cn.endsWith("Test") || cn.contains("Test")))
                        && isReturn(opcode)))) {
            //TODO
            this.mv.visitMethodInsn(Opcodes.INVOKESTATIC, "inst/InstrumentationUtils",
                    "dumpProbesPerTest", "()V", false);
        }
        super.visitInsn(opcode);
    }

    @Override
    public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) {
        if (descriptor.endsWith("/Test;") || descriptor.endsWith("/ParameterizedTest;") ||
                descriptor.endsWith("/BeforeEach;") || descriptor.endsWith("/BeforeAll;") ||
                descriptor.endsWith("/AfterEach;") || descriptor.endsWith("/AfterAll;") ) {
            this.hasTestAnnotation = true;
            if (descriptor.endsWith("/BeforeAll;")) {
                this.hasBeforeAll = true;
            }
        }
        return super.visitAnnotation(descriptor, visible);
    }

    public static Set<Integer> returnStm = new HashSet<Integer>();

    static {
        // initialze returnStm sets
        returnStm.add(Opcodes.IRETURN);
        returnStm.add(Opcodes.FRETURN);
        returnStm.add(Opcodes.ARETURN);
        returnStm.add(Opcodes.LRETURN);
        returnStm.add(Opcodes.RETURN);
        returnStm.add(Opcodes.DRETURN);
    }

    public static Boolean isReturn(int op) {
        if (returnStm.contains(op)) {
            return true;
        }
        return false;
    }
}


