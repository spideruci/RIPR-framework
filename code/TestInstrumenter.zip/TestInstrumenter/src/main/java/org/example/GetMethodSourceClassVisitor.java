package org.example;

import org.objectweb.asm.AnnotationVisitor;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

public class GetMethodSourceClassVisitor extends ClassVisitor {



    public GetMethodSourceClassVisitor() {
        super(Opcodes.ASM9);
    }



    @Override
    public MethodVisitor visitMethod(int access, String name, String descriptor, String signature, String[] exceptions) {
        return new GetMethodSourceMethodVisitor();
//        return mv;
    }

    static class MyAnnotationVisitor extends AnnotationVisitor {

        protected MyAnnotationVisitor(int api) {
            super(api);
        }

        @Override
        public void visit(String name, Object value) {
//            System.err.println("Annotation: " + name + " = " + value.toString());
            super.visit(name, value);
        }

    }


    static class GetMethodSourceMethodVisitor extends MethodVisitor {

        protected GetMethodSourceMethodVisitor() {
            super(Opcodes.ASM9);
        }

        @Override
        public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) {
//
//            System.out.println("annotation type: " + descriptor);
//        AnnotationVisitor av = super.visitAnnotation(descriptor, visible);
//            if (descriptor.equals("Lorg/junit/jupiter/params/provider/MethodSource;")) {
//                System.err.println("return something");
//                return new MyAnnotationVisitor(Opcodes.ASM9);
//            }
//            return super.visitAnnotation(descriptor, visible);
            return new MyAnnotationVisitor(Opcodes.ASM9);
        }
    }

}


