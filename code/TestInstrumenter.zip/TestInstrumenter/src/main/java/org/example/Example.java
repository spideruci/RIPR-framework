package org.example;

public class Example {

    public void doSomething() {
        System.err.println("Something");
        int x = 1;
        int y = 2;
        System.err.println(x + y);
    }
}
