package org.example;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestParent {

    public static int staticX;
    public static TestParent staticY;


    TestParent() {

    }

    @Test
    public void test1() {
        assertEquals(true,true);
    }

}
