package org.example;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.concurrent.atomic.AtomicLong;


public class TestI {

    public static AtomicLong x = new AtomicLong(0);
    @BeforeAll
    public static void ba() {
//        new Example().doSomething();
        System.err.println("BeforeAll");
    }

    @BeforeEach
    public void be() {
        System.err.println("BeforeEach");
    }

    @Test
    public void test1() {
        new Example().doSomething();
        new Example().doSomething();
        System.err.println("test1");
    }

    @Test
    public void test2() {
        try {
            new Example().doSomething();
            new Example().doSomething();
            System.err.println("test2");
        } catch (RuntimeException t){
            throw t;
        }
    }


    @AfterEach
    public void ae() {
        System.err.println("AfterEach");
    }

    @AfterAll
    public static void aa() {
        System.err.println("AfterAll");
    }




}
