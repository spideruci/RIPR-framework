package org.example;

import org.junit.jupiter.api.Test;

//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//
//import static org.junit.jupiter.api.Assertions.assertTrue;
//
public class TestBeforeEach {

    @Test
    public void test1() {

    }

}
