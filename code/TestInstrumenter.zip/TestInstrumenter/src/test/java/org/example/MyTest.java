package org.example;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

public class MyTest {

    private static final Character[] BINARY = {'0', '1'};

    @Test
    public void doSomething() {
        System.err.println(BINARY[0]);
        BINARY[0] = 2;
    }

    @BeforeAll
    public static void doBeforeAll() {
        System.err.println("beforeAll");
    }

}
