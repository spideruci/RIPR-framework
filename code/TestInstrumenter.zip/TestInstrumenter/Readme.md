# This project is for instrumenting test cases

## what is this project doing?
Methods that can make up a test case will be surrounded by an try-catch block
If a test fails: Any exceptions will be rethrown while probe info will be dumped to files.

If a test succeeds: probe info will be collected periodically (At the end of method ``@Test``, ``@ParameterizedTest``,  ``AfterEach``, ``AfterAll``)


## Project Requirements:
1. Junit 5 (Junit 4 not supported)
2. single module maven project
3. ``@Test(expected = xxxx)`` style not supported
4. Test classes constructors should not be explicitly specified (use ``@Before` instead)
5. Test classes shouldn't have inheritance. If it has, transform it manually.
### dependencies
```
    <dependencies>
        <dependency>
            <groupId>com.thoughtworks.xstream</groupId>
            <artifactId>xstream</artifactId>
            <version>1.4.19</version>
        </dependency>
        <dependency>
            <groupId>org.ow2.asm</groupId>
            <artifactId>asm</artifactId>
            <version>9.4</version>
        </dependency>
        <dependency>
            <groupId>org.junit.jupiter</groupId>
            <artifactId>junit-jupiter</artifactId>
            <version>5.X.X</version>
            <scope>test</scope>
        </dependency>
        <dependency>
            <groupId>org.apache.commons</groupId>
            <artifactId>commons-lang3</artifactId>
            <version>3.12.0</version>
        </dependency>
    </dependencies>
```

## How things are done?
### Which files will be instrumented?
1. all files target/test-classes
2. file name starting with ``Test`` or ending with ``Tes``

Which method body will be instrumented with try-catch block?
1. constructors
2. "static blocks", with following annotations:
       ``@Test``, ``@ParameterizedTest``, ``BeforeEach``, ``BeforeAll``, ``AfterEach``, ``AfterAll``