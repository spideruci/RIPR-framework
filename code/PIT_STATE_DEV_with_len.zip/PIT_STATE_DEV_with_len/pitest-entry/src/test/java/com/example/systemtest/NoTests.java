package com.example.systemtest;

public class NoTests {

}
