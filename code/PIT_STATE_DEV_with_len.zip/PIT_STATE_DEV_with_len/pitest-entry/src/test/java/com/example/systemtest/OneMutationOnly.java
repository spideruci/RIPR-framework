package com.example.systemtest;

public class OneMutationOnly {
    public static int returnOne() {
        return 1;
    }
}
