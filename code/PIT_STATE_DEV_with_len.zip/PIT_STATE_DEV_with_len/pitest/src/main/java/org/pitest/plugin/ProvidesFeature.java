package org.pitest.plugin;

public interface ProvidesFeature {
  Feature provides();
}
