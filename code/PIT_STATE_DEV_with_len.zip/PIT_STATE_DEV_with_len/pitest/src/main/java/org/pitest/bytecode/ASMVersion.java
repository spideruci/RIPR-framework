package org.pitest.bytecode;

import org.objectweb.asm.Opcodes;

public class ASMVersion {
  public static final int ASM_VERSION = Opcodes.ASM9;
}
