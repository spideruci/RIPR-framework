package stateprobe.pitest.MethodEndInstrumentation;

import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import stateprobe.pitest.ProblemRecorder;

public class NMRMethodEndClassVisitor extends ClassVisitor {

    private String className;
    public NMRMethodEndClassVisitor(ClassVisitor cv) {
        super(Opcodes.ASM9, cv);
    }

//    @Override
//    public FieldVisitor visitField(int access, String name, String descriptor, String signature, Object value) {
//        boolean isStatic = (access & Opcodes.ACC_STATIC) != 0;
//
//        if (isStatic) {
//            // Remove the final modifier
//            access &= ~Opcodes.ACC_FINAL;
//
//            // Make the field public static
//            access |= Opcodes.ACC_PUBLIC | Opcodes.ACC_STATIC;
//        }
//        return super.visitField(access, name, descriptor, signature, value);
//    }

    @Override
    public void visit(int version, int access, String name, String signature, String superName, String[] interfaces) {
        super.visit(version, access, name, signature, superName, interfaces);
        this.className = name;
    }

    @Override
    public MethodVisitor visitMethod(int access, String name, String descriptor, String signature, String[] exceptions) {
        String mutatedRecord = ProblemRecorder.readOneLine("target/mutatedDesc.txt");
        String[] splitResults = mutatedRecord.split(" ");
        String ownerClass = splitResults[0].replace(".","/");
        String methodName = splitResults[1];
        String methodDesc = splitResults[2];

        if (this.className.equals(ownerClass) && name.equals(methodName) && descriptor.equals(methodDesc)) {
            MethodVisitor mv = this.cv.visitMethod(access, name, descriptor, signature, exceptions);
            return new NMRMethodEndMethodVisitor(Opcodes.ASM9,mv, access, name, descriptor);
        } else {
            return super.visitMethod(access, name, descriptor, signature, exceptions);
        }

    }
}
