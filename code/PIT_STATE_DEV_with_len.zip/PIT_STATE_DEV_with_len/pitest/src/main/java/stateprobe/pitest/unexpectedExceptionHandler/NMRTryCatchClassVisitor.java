package stateprobe.pitest.unexpectedExceptionHandler;

import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;
import stateprobe.pitest.ProblemRecorder;

public class NMRTryCatchClassVisitor extends ClassVisitor {

    private String className;

    private int access;

    private String descriptor;

    private String superName;

    private String methodName;

    private boolean isStatic;
    public NMRTryCatchClassVisitor(ClassVisitor cv) {
        super(Opcodes.ASM9, cv);
        this.className = null;
    }

    @Override
    public void visit(int version, int access, String name, String signature, String superName, String[] interfaces) {
        this.className = name;
        this.superName = superName;
        super.visit(version, access, name, signature, superName, interfaces);
    }

    @Override
    public MethodVisitor visitMethod(int access, String name, String descriptor, String signature, String[] exceptions) {
        String mutatedRecord = ProblemRecorder.readOneLine("target/mutatedDesc.txt");
        String[] splitResults = mutatedRecord.split(" ");
        String ownerClass = splitResults[0].replace(".","/");
        String methodName = splitResults[1];
        String methodDesc = splitResults[2];
        this.access = access;
        this.descriptor = descriptor;
        this.methodName = name;

        boolean isStatic = (access & Opcodes.ACC_STATIC) != 0;

        int sizeParas = 0;
        for (Type t: Type.getArgumentTypes(descriptor)) {
            if (t.toString().equals("J") || t.toString().equals("D")) {
                sizeParas += 2;
            } else {
                sizeParas += 1;
            }
        }

        if (this.className.equals(ownerClass) && name.equals(methodName) && descriptor.equals(methodDesc)) {
            MethodVisitor mv = this.cv.visitMethod(access, name, descriptor, signature, exceptions);
            return new NMRTryCatchMethodVisitor(api, mv, isStatic, access, descriptor, sizeParas, superName, methodName, className);
        } else {
            return super.visitMethod(access, name, descriptor, signature, exceptions);
        }
    }
}
