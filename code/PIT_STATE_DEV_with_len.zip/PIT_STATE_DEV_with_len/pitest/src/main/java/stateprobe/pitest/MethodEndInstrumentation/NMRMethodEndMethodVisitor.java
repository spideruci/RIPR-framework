package stateprobe.pitest.MethodEndInstrumentation;

import org.objectweb.asm.Label;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;
import org.objectweb.asm.commons.AdviceAdapter;
import stateprobe.pitest.AsmUtils;
import stateprobe.pitest.ProblemRecorder;
import java.util.List;
import java.util.Set;

public class NMRMethodEndMethodVisitor extends AdviceAdapter {

    private String descriptor;

    private String stateInfo;

    private int access;

    @Override
    protected void onMethodEnter() {
        this.mv.visitMethodInsn(Opcodes.INVOKESTATIC, "inst/InstrumentationUtils","visitNProbeNMR","()V",false);
        super.onMethodEnter();
    }

    @Override
    protected void onMethodExit(int opcode) {
        //put the return value on the stack -- check if the mutation has been executed
        this.mv.visitMethodInsn(Opcodes.INVOKESTATIC, "inst/InstrumentationUtils",
                "shouldDumpStateForNMR", "()I", false);
        mv.visitInsn(Opcodes.ICONST_1);
        instrumentIfElseBlock(opcode);
        super.onMethodExit(opcode);
    }

    protected NMRMethodEndMethodVisitor(int api, MethodVisitor methodVisitor, int  access, String name, String descriptor) {
        super(api, methodVisitor, access, name, descriptor);
        this.descriptor = descriptor;
        this.access = access;
    }

//
//    /**
//     * insert one probe at the beginning of a method body
//     * nProbeNMR: counter probe: how many times the invoked method has been visited before the state is executed
//     */
//    @Override
//    public void visitCode() {
//        //insert nProbeNMR, unconditionally increase 1
//        this.mv.visitMethodInsn(Opcodes.INVOKESTATIC, "InstrumentationUtils","visitNProbeNMR","()V",false);
//        super.visitCode();
//    }
//
//    @Override
//    public void visitInsn(int opcode) {
//        if (AsmUtils.isReturn(opcode)) {
//            //put the return value on the stack -- check if the mutation has been executed
//            this.mv.visitMethodInsn(Opcodes.INVOKESTATIC, "InstrumentationUtils",
//                    "shouldDumpStateForNMR", "()I", false);
//            mv.visitInsn(Opcodes.ICONST_1);
//            instrumentIfElseBlock();
//        }
//        super.visitInsn(opcode);
//    }

    /**
     * instrument IF-else block, a boolean value should be on the stack before using this method
     */
    private void instrumentIfElseBlock(int opcode) {


        Label elseLabel = new Label();
        Label endLabel = new Label();
        mv.visitJumpInsn(Opcodes.IF_ICMPNE, elseLabel);

        // if block - if equal to 1

        mv.visitJumpInsn(Opcodes.GOTO, endLabel);
        mv.visitLabel(elseLabel);

        //else block -- else: dump states
        dumpStates(opcode);

        //instrument some code
        mv.visitLabel(endLabel);

    }

    /**
     * dump states for:
     * all arguments of the method,
     * static fields
     * return value(if it has),
     * "this" if the method is non-static
     */
    private void dumpStates(int opcode) {
        // this is an example of methodDesc
        // (Ljava/lang/Long;Ljava/lang/Boolean;Ljava/lang/Float;Ljava/lang/Short;Lorg/example/MainCode;I)I

        //JCL classes have been filtered out for static fields
        boolean isStatic = AsmUtils.isStatic(access);
        List<String> args = AsmUtils.getArgTypes(descriptor);
        Set<String> staticFields = ProblemRecorder.getStaticFields();
        String returnType = AsmUtils.getReturnType(descriptor);
        //calculate the number of variables/fields being tracked
        int size = getSize(staticFields, returnType, args, isStatic, opcode);

        //create an object array of num size
        this.mv.visitLdcInsn(size);
        this.mv.visitTypeInsn(Opcodes.ANEWARRAY, Type.getInternalName(Object.class));
        this.mv.visitFieldInsn(Opcodes.PUTSTATIC,"inst/InstrumentationUtils","_states","[Ljava/lang/Object;");

        int arrayIndex = 0;
        int stackIndex = 0;

        //1. dump return values
        if (opcode == ATHROW) {
            visitInsn(Opcodes.DUP);
            this.mv.visitFieldInsn(Opcodes.GETSTATIC,"inst/InstrumentationUtils","_states","[Ljava/lang/Object;");
            visitInsn(Opcodes.SWAP);
            if (arrayIndex > 127) {
                this.mv.visitIntInsn(Opcodes.SIPUSH, arrayIndex);
            } else {
                this.mv.visitIntInsn(Opcodes.BIPUSH, arrayIndex);
            }
            visitInsn(Opcodes.SWAP);

            this.mv.visitInsn(Opcodes.AASTORE);
            arrayIndex += 1;
        } else if (!returnType.equals("V")) {
            // For Non-long/double type return value
            if (!returnType.equals("D") && !returnType.equals("J")) {
                visitInsn(Opcodes.DUP);
                this.mv.visitFieldInsn(Opcodes.GETSTATIC,"inst/InstrumentationUtils","_states","[Ljava/lang/Object;");
                visitInsn(Opcodes.SWAP);
                if (arrayIndex > 127) {
                    this.mv.visitIntInsn(Opcodes.SIPUSH, arrayIndex);
                } else {
                    this.mv.visitIntInsn(Opcodes.BIPUSH, arrayIndex);
                }
                visitInsn(Opcodes.SWAP);
                //copy and put the return value/reference onto the operand stack
            } else {
                visitInsn(Opcodes.DUP2);
                this.mv.visitFieldInsn(Opcodes.GETSTATIC,"inst/InstrumentationUtils","_states","[Ljava/lang/Object;");
                visitInsn(Opcodes.DUP_X2);
                visitInsn(Opcodes.POP);
                if (arrayIndex > 127) {
                    this.mv.visitIntInsn(Opcodes.SIPUSH, arrayIndex);
                } else {
                    this.mv.visitIntInsn(Opcodes.BIPUSH, arrayIndex);
                }
                visitInsn(Opcodes.DUP_X2);
                visitInsn(Opcodes.POP);
            }

            if (AsmUtils.isPrimitive(returnType)) {
                this.mv.visitMethodInsn(Opcodes.INVOKESTATIC,
                        "java/lang/" + AsmUtils.desToType(returnType),
                        "valueOf",
                        "(" + returnType + ")Ljava/lang/" + AsmUtils.desToType(returnType) + ";",
                        false);
            }
            this.mv.visitInsn(Opcodes.AASTORE);
            arrayIndex += 1;
        }

        //2. dump "this"
        if (!isStatic) {
            this.mv.visitFieldInsn(Opcodes.GETSTATIC,"inst/InstrumentationUtils","_states","[Ljava/lang/Object;");
            if (arrayIndex > 127) {
                this.mv.visitIntInsn(Opcodes.SIPUSH, arrayIndex);
            } else {
                this.mv.visitIntInsn(Opcodes.BIPUSH, arrayIndex);
            }
            this.mv.visitVarInsn(Opcodes.ALOAD, stackIndex);
            this.mv.visitInsn(Opcodes.AASTORE);
            arrayIndex += 1;
            stackIndex += 1;
        }

        /**
         * 3. dump arguments
         *         //ALL primitive types
         *         // BCDFIJSZ
         *
         *         //primitive type - load type - space on operand stack
         *         //J              - lload     - 2
         *         //D              - dload     - 2
         *
         *         //Z              - iload     - 1
         *         //S              - iload     - 1
         *         //I              - iload     - 1
         *         //B              - iload     - 1
         *         //C              - iload     - 1
         *
         *         //F              - fload     - 1
         */
        for (String s: args) {
            //didn't filter JCL classes out. will keep it?

            this.mv.visitFieldInsn(Opcodes.GETSTATIC,"inst/InstrumentationUtils","_states","[Ljava/lang/Object;");
            if (arrayIndex > 127) {
                this.mv.visitIntInsn(Opcodes.SIPUSH, arrayIndex);
            } else {
                this.mv.visitIntInsn(Opcodes.BIPUSH, arrayIndex);
            }
            switch (s) {
                case "J":
                    this.mv.visitVarInsn(Opcodes.LLOAD, stackIndex);
                    this.mv.visitMethodInsn(Opcodes.INVOKESTATIC, "java/lang/Long", "valueOf","(J)Ljava/lang/Long;",false);
                    stackIndex += 2;
                    break;
                case "D":
                    this.mv.visitVarInsn(Opcodes.DLOAD, stackIndex);
                    this.mv.visitMethodInsn(Opcodes.INVOKESTATIC, "java/lang/Double", "valueOf","(D)Ljava/lang/Double;",false);
                    stackIndex += 2;
                    break;
                case "I":
                case "B":
                case "C":
                case "S":
                case "Z":
                    this.mv.visitVarInsn(Opcodes.ILOAD, stackIndex);
                    String typeName = AsmUtils.desToType(s);
                    this.mv.visitMethodInsn(Opcodes.INVOKESTATIC, "java/lang/" + typeName, "valueOf",
                            "(" + s + ")Ljava/lang/" + typeName + ";",false);
                    stackIndex += 1;
                    break;
                case "F":
                    this.mv.visitVarInsn(Opcodes.FLOAD, stackIndex);
                    this.mv.visitMethodInsn(Opcodes.INVOKESTATIC, "java/lang/Float", "valueOf","(F)Ljava/lang/Float;",false);
                    stackIndex += 1;
                    break;
                default:
                    // reference types
                    this.mv.visitVarInsn(Opcodes.ALOAD, stackIndex);
                    stackIndex += 1;
                    break;
            }
            this.mv.visitInsn(Opcodes.AASTORE);
            arrayIndex += 1;
        }

//        4. dump static fields
        this.mv.visitFieldInsn(Opcodes.GETSTATIC,"inst/InstrumentationUtils","_states","[Ljava/lang/Object;");
        this.mv.visitIntInsn(Opcodes.BIPUSH, arrayIndex);
        this.mv.visitMethodInsn(Opcodes.INVOKESTATIC, "inst/InstrumentationUtils","dumpStaticInMiddle","([Ljava/lang/Object;I)V",false);

//        for (String f: staticFields) {
//            String[] temp = f.split(" ");
//            String owner = temp[0];
//            String name = temp[1];
//            String des = temp[2];
//
//            this.mv.visitFieldInsn(Opcodes.GETSTATIC,"inst/InstrumentationUtils","_states","[Ljava/lang/Object;");
//            if (arrayIndex > 127) {
//                this.mv.visitIntInsn(Opcodes.SIPUSH, arrayIndex);
//            } else {
//                this.mv.visitIntInsn(Opcodes.BIPUSH, arrayIndex);
//            }
////            System.err.println("static: " + owner + " " + name + " " + des);
//            this.mv.visitFieldInsn(Opcodes.GETSTATIC, owner, name, des);
//            //convert to non-primitive type if necessary
//            if (AsmUtils.isPrimitive(des)) {
//                this.mv.visitMethodInsn(Opcodes.INVOKESTATIC,
//                        "java/lang/" + AsmUtils.desToType(des),
//                        "valueOf",
//                        "(" + des + ")Ljava/lang/" + AsmUtils.desToType(des) + ";",
//                        false);
//            }
//            this.mv.visitInsn(Opcodes.AASTORE);
//            arrayIndex += 1;
//        }

        //5. dump the array to a file using XStream
        dumpArray("temp","temp1","temp2");
    }

    private int getSize(Set<String> staticFields, String returnType, List<String> args,
                        boolean isStatic, int opcode) {
        int numReturn = 0, numAthrow = 0, numThis = 0, numUnexpectedException = 0, numArgs = 0, numStatic = 0;
        numStatic = staticFields.size();
        if (opcode == Opcodes.ATHROW) {
            numAthrow = 1;
        } else if (!returnType.equals("V")) {
            numReturn = 1;
        }
        numArgs = args.size();
        if (!isStatic) {
            numThis = 1;
        }
        stateInfo = numReturn + " " + numAthrow + " "
                + numUnexpectedException + " " + numThis
                + " " + numArgs + " " + numStatic;
        return numReturn + numAthrow + numThis + numUnexpectedException + numArgs + numStatic;
    }
    private void dumpArray(String fileName, String parentFolderName, String secondFolderName) {
        this.mv.visitFieldInsn(Opcodes.GETSTATIC,"inst/InstrumentationUtils","_states","[Ljava/lang/Object;");
        //dump the object array using XStream
        this.mv.visitLdcInsn(fileName);
        this.mv.visitLdcInsn(parentFolderName);
        this.mv.visitLdcInsn(secondFolderName);
        this.mv.visitMethodInsn(Opcodes.INVOKESTATIC, "inst/InstrumentationUtils",
                "dumpObjectUsingXml", "(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", false);

        this.mv.visitLdcInsn(stateInfo);
        this.mv.visitLdcInsn("target/stateInfo.txt");
        this.mv.visitMethodInsn(Opcodes.INVOKESTATIC, "inst/InstrumentationUtils",
                "addOneLine", "(Ljava/lang/String;Ljava/lang/String;)V", false);
    }
}
