package stateprobe.pitest;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.ClassWriter;
import org.pitest.mutationtest.MutationStatusTestPair;
import org.pitest.mutationtest.engine.Mutant;
import org.pitest.mutationtest.engine.MutationDetails;
import org.pitest.mutationtest.execute.CheckTestHasFailedResultListener;
import org.pitest.mutationtest.execute.HotSwap;
import org.pitest.testapi.Description;
import org.pitest.testapi.TestResult;
import org.pitest.testapi.TestUnit;
import org.pitest.testapi.execute.Container;
import org.pitest.testapi.execute.ExitingResultCollector;
import org.pitest.testapi.execute.Pitest;
import org.pitest.testapi.execute.containers.ConcreteResultCollector;
import org.pitest.testapi.execute.containers.UnContainer;
import org.pitest.util.Log;
import stateprobe.pitest.MethodEndInstrumentation.NMRMethodEndClassVisitor;
import stateprobe.pitest.unexpectedExceptionHandler.NMRTryCatchClassVisitor;

//import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import java.util.stream.Collectors;


import static org.pitest.util.Unchecked.translateCheckedException;

public class OriginalTestWorker {
    private static final Logger LOG   = Log.getLogger();
    private static HotSwap hotswap;

    private static ClassLoader loader;
    public static void handleOriginal(
            final MutationDetails mutationId, final Mutant mutatedClass,
            final List<TestUnit> relevantTests,
            HotSwap hotswap, ClassLoader loader) {
        OriginalTestWorker.hotswap = hotswap;
        OriginalTestWorker.loader = loader;
        if ((relevantTests == null) || relevantTests.isEmpty()) {
            LOG.info(() -> "no covering tests");
        } else {
            LOG.info("running original code");
            handleCoveredOriginal(mutationId, mutatedClass, relevantTests);
        }
    }

    private static void handleCoveredOriginal(
            final MutationDetails mutationId, final Mutant mutatedClass,
            final List<TestUnit> relevantTests) {

        LOG.fine("" + relevantTests.size() + " relevant test for "
                    + mutatedClass.getDetails().getMethod());
        // replace the mutant with original code to enable two original test runs.
        //instrument the original class bytecode to get NMR states
        ClassReader cr = new ClassReader(mutatedClass.getSource());
        ClassWriter cw = new ClassWriter(cr, ClassWriter.COMPUTE_FRAMES);
        ClassVisitor stateRecorder = new NMRMethodEndClassVisitor(cw);
        cr.accept(stateRecorder, ClassReader.EXPAND_FRAMES);

        //second time instrumentation for NMR, surround the mutated method with a try-catch block to see unexpected method
        ClassReader cr2 = new ClassReader(cw.toByteArray());
        ClassWriter cw2 = new MyClassWriter(cr2, ClassWriter.COMPUTE_FRAMES);
        ClassVisitor tryInstrumenter = new NMRTryCatchClassVisitor(cw2);
        cr2.accept(tryInstrumenter, ClassReader.EXPAND_FRAMES);

        // for debugging, use IDE to see what's the problem here.
//        try {
//          PrintStream byteStream = new PrintStream("target/test-classes/" + mutationId.hashCode() + ".class");
//          byteStream.write(cw2.toByteArray());//changed cw cw2.toByteArray()
//          byteStream.close();
//        } catch (Exception e) {
//          e.printStackTrace();
//          System.err.println("something wrong");
//        }


        if (hotswap.insertClass(mutationId.getClassName(),loader, cw2.toByteArray())) {
            doTenOriginalRuns(relevantTests,mutatedClass, mutationId);
        } else {
            LOG.warning("fail to replace with the original source code");
        }
        LOG.fine("finished running original code");

    }

    private static Container createNewContainer() {
        return new UnContainer() {
            @Override
            public List<TestResult> execute(final TestUnit group) {
                final List<TestResult> results = new ArrayList<>();
                final ExitingResultCollector rc = new ExitingResultCollector(
                        new ConcreteResultCollector(results));
                group.execute(rc);
                return results;
            }
        };
    }

    private static MutationStatusTestPair doTestsDetectMutation(final Container c,
                                                                final List<TestUnit> tests) {
        try {
            final CheckTestHasFailedResultListener listener = new CheckTestHasFailedResultListener(true);

            final Pitest pit = new Pitest(listener);

            pit.run(c, tests);

            return createStatusTestPair(listener);
        } catch (final Exception ex) {
            throw translateCheckedException(ex);
        }

    }

    private static MutationStatusTestPair createStatusTestPair(
            final CheckTestHasFailedResultListener listener) {
        List<String> failingTests = listener.getFailingTests().stream()
                .map(Description::getQualifiedName).collect(Collectors.toList());
        List<String> succeedingTests = listener.getSucceedingTests().stream()
                .map(Description::getQualifiedName).collect(Collectors.toList());

        return new MutationStatusTestPair(listener.getNumberOfTestsRun(),
                listener.status(), failingTests, succeedingTests);
    }

    private static void doTenOriginalRuns(final List<TestUnit> relevantTests, Mutant mutatedClass, final MutationDetails mid) {
        for (int runNum = 0; runNum < 10; runNum++) {
            ProblemRecorder.setWhichOriginalRun(runNum);
            Container c = createNewContainer();
//            try {
            MutationStatusTestPair pairResult = doTestsDetectMutation(c, relevantTests);
            //record flaky test runs
            //flaky test here refers to a test that sometimes pass while sometimes fail
            if (!pairResult.getKillingTests().isEmpty()) {
                ProblemRecorder.dumpOriginalFailingInfo(pairResult, mutatedClass, runNum, mid);
            }
//            } catch (Throwable t) {
//                ProblemRecorder.addOneLine(t.toString(), "target/OriginalTimedOutInfo.txt");
//            }
        }
    }
}
