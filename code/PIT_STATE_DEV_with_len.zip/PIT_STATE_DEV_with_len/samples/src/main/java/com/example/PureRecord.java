package com.example;

public record PureRecord(Long timeStamp, String data) {
}
